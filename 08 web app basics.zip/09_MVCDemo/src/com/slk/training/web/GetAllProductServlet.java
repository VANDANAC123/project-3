package com.slk.training.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;
import javax.servlet.RequestDispatcher;

import com.slk.training.dao.ProductManager;
import com.slk.training.entity.Product;

/**
 * Servlet implementation class GetAllProductServlet
 */
@WebServlet({"/GetAllProductServlet","/get-all-product"})
public class GetAllProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//step 1: read all the inputs from the request(if any)
		//step 2: invoke the model functions to get data for the output
		ProductManager pm=new ProductManager();
		List<Product> list=pm.getAllProduct();
		
		request.setAttribute("products", list);
		
		RequestDispatcher rd=request.getRequestDispatcher("show-products.jsp");
		rd.forward(request, response);

}
}
