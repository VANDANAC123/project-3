package com.slk.training.dao;

import java.sql.DriverManager;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.slk.training.entity.Product;

public class ProductManager {
	private Connection openConnection() throws ClassNotFoundException, SQLException {
		Class.forName("org.h2.Driver");
		String url="jdbc:h2:~/test";
		String user="sa";
		String password=" ";
		return  DriverManager.getConnection(url, user, password);
	}
	public List<Product> getAllProduct(){
 List<Product> list=new ArrayList<>();
	
	try( 
			Connection conn=openConnection();
			PreparedStatement stmt=conn.prepareStatement("select * from product");
			ResultSet rs=stmt.executeQuery();
			){
		while(rs.next()) {
			Product p=new Product();
			p.setId(rs.getInt("id"));
			p.setName(rs.getString("name"));
			p.setCategory(rs.getString("category"));
			p.setPrice(rs.getDouble("price"));
			list.add(p);
			
		}
	}
	catch(Exception ex) {
		ex.printStackTrace();
	}
	return list;
			
	
	
	
		
		
		
	}

}
